# DBS Platform — Legacy .NET Modernizasyonu

Legacy `cashmanagementnew` çözümündeki .NET Framework 4.5.2 Windows Service'lerinin
Spring Boot 4.1 + Java 25 üzerine taşınması. İlk modül: **`DBS.ReadExchangeMailAccount`**.

---

## 1. Legacy kod analizi

### Ne yapıyor?

`DBS.ReadExchangeMailAccount` bir Windows Service. `MailReader.OnStart` bir
`System.Timers.Timer` başlatıyor (60 sn), her tick'te iki iş yapılıyor:

1. **`ExchangeReader.CheckMails()`** — EWS (`Microsoft.Exchange.WebServices` 2.2) ile
   on-prem Exchange sunucusuna bağlanıyor (`http://ex-ht-cas-01/ews/exchange.asmx`),
   son 24 saatte gelen ilk 50 maili çekiyor, eklerini
   `C:\_ExampleDBSDosyalari\{gönderen}!{dosyaadı}` olarak diske yazıyor ve
   **maili siliyor**.
2. **`FTPHelper.SendFileToFtpOrConvertionPath()`** — o klasördeki `.txt` dosyalarını
   `!` ayracından bölüp gerçek adına döndürüyor, SFTP'ye (port 22 → `SFTPHelper`,
   diğer portlar → `FTPHelper`) yüklüyor, sonra `Arsiv` klasörüne taşıyor.
   Uygun olmayan dosyalar `Unknown` klasörüne taşınıp gönderene HTML bir hata
   maili atılıyor.

Yani: **Exchange gelen kutusu → yerel disk → SFTP**. Doğru tahmin etmişsin.

### Tespit edilen hatalar ve riskler

| # | Yer | Sorun |
|---|-----|-------|
| 1 | `ExchangeReader.CheckMails` | Mail **işlenmeden önce** siliniyor (`MoveToDeletedItems`). SFTP adımı patlarsa dosya kalıcı olarak kayıp. |
| 2 | `ExchangeReader.CheckMails` | `message.Attachments[0] is FileAttachment` kontrolü sadece ilk eke bakıyor, sonra tüm ekleri işliyor. İlk ek inline imza resmi ise **bütün ekler atlanıyor**. |
| 3 | `ExchangeReader.CheckMails` | Eki olmayan mailler de siliniyor. |
| 4 | `ExchangeReader.CheckMails` | `ItemView(50)` — sayfalama yok. 50'den fazla mail gelirse fazlası düşüyor. |
| 5 | `ExchangeReader` | `ExchangeService` alan olarak tutulup hiç `Dispose` edilmiyor. |
| 6 | `FTPHelper` (satır ~48) | `Unknown` klasörü hiç yaratılmıyor — sadece `Arsiv` yaratılıyor. İlk hatalı dosyada `DirectoryNotFoundException`. |
| 7 | `FTPHelper` | `fileDetails[1]` — dosya adında `!` yoksa `IndexOutOfRangeException`. |
| 8 | `FTPHelper` | Döngü içinde `return` var (`SendErrorInformationMails` sonrası). **Tek hatalı dosya, kuyruktaki tüm dosyaların işlenmesini durduruyor.** |
| 9 | `FTPHelper` | `File.Move(sftp.SourceFilePath + f, ...)` — dizin ayracı eksik; başka satırlarda `+ "\\" +` var, tutarsız. |
| 10 | `FTPHelper` | `f.Name.Contains("DBS_")` — `XDBS_gizli.txt` de geçerli sayılıyor. `StartsWith` olmalı. |
| 11 | `FTPHelper` | `private static StreamWriter _writer` — **static, thread-safe değil**. Eşzamanlı çağrılar birbirinin dosyasına yazar. |
| 12 | `FTPHelper.SendErrorInformationMails` | HTML gövde `Guid` isimli geçici dosyaya yazılıyor, geri okunuyor ve **dosya hiç silinmiyor**. Disk zamanla doluyor. |
| 13 | `FTPHelper` | Port numarasına bakarak protokol tahmini (`Port == 22 \|\| 23 \|\| 26`). |
| 14 | `SFTPHelper` | Host key doğrulaması yok — MITM'e açık. |
| 15 | Ek adı işleme | Ek adı doğrudan yola ekleniyor → **path traversal**. Dışarıdan gelen bir mailde ek adı `..\..\windows\...` olabilir. |
| 16 | `MailReader.OnStop` | Boş (`// BUG` yorumu zaten kodda duruyor). Servis durdurulurken devam eden iş yarıda kalıyor. |
| 17 | Tümü | İdempotency yok. Servis yeniden başlarsa / silme başarısız olursa aynı dosya tekrar SFTP'ye gidiyor. |
| 18 | Tümü | Retry, DLQ, metrik, correlation-id yok. Hatalar `EH.Error.CreateError` ile yutuluyor. |
| 19 | `Assembly.GetCallingAssembly()` | Log'daki proje adı çağıran assembly'ye göre değişiyor — güvenilmez. |

### ⚠️ Güvenlik — acil

`log4net.config` içinde **düz metin SQL Server bağlantı bilgisi** var:

```
Data Source=NYBSRVDB; Initial Catalog=NAKITYONETIMI; User ID=Nakityonetimi2; Password=<...>
```

Bu dosya repoda duruyor. `App.config`'teki diğer şifreler örnekte maskelenmiş ama
bu maskelenmemiş. **Bu hesabın şifresini rotate edin** ve git geçmişinden temizleyin
(`git filter-repo` / BFG). Yeni yapıda hiçbir sır YAML'da tutulmuyor — hepsi
ortam değişkeni / Vault referansı.

---

## 2. Yeni mimari

```
dbs-platform/                     Maven parent (Java 25, Spring Boot 4.1)
├── dbs-common/                   Altyapı: BaseRequest/Response, hata yönetimi, AOP
├── dbs-messaging/                Kafka + RabbitMQ publisher soyutlaması, Outbox
└── dbs-mail-reader/              ReadExchangeMailAccount'un yerine geçen servis
```

Diğer legacy projeler (`DBS.SendInformationMail`, `DBS.EndOfDaySummaryMail`,
`CEK.SendChequeResults`, ...) sırayla yeni modül olarak eklenecek; `dbs-common`
ve `dbs-messaging` hepsinde ortak.

### Hexagonal (Ports & Adapters)

```
interfaces/rest  ──►  application  ──►  domain/port  ◄──  infrastructure/*
  Controller          IngestionService     MailClientPort       ImapAdapter
                      RuleChain            FileTransferPort     SshjAdapter
                                           AttachmentStorePort  LocalStore
                                           EventPublisher       Kafka/Rabbit
```

Uygulama katmanı IMAP mı Graph mı, Kafka mı Rabbit mı bilmiyor. Adapter'lar
konfigürasyonla seçiliyor.

### Kullanılan desenler

| Desen | Nerede | Niye |
|-------|--------|------|
| **Ports & Adapters** | `domain/port/*` | Exchange → IMAP → Graph geçişi iş kodunu bozmasın |
| **Strategy** | `MailClientPort`, `FileTransferPort` | Sağlayıcı değişimi = yeni sınıf, `switch` değil |
| **Factory** | `MailClientResolver` | Aktif sağlayıcıyı config'den seçer |
| **Chain of Responsibility** | `AttachmentRuleChain` | Legacy'deki iç içe `if/else` yerine bağımsız kurallar |
| **Composite** | `RoutingEventPublisher` | Aynı olayı Kafka + Rabbit'e birden basma |
| **Transactional Outbox** | `dbs-messaging/outbox` | "DB yazıldı ama event gitmedi" tutarsızlığını çözer |
| **Sealed interface + pattern matching** | `ProcessingOutcome`, `Verdict` | Her durum tip güvenli ele alınır, `default` dalı yok |
| **AOP** | `LoggingAspect`, `AuditAspect` | Loglama ve denetim iş kodundan ayrık |

### Kritik davranış değişiklikleri

| Legacy | Yeni |
|--------|------|
| Mail hemen siliniyor | Mail **başarılı işlemden sonra** `DBS-Archive` klasörüne taşınıyor |
| İdempotency yok | `DBS_PROCESSED_MAIL.MESSAGE_ID` unique index |
| Tek hatada döngü duruyor | Her mail izole; biri patlarsa diğerleri devam ediyor |
| Retry yok | `@Retryable` (Spring Framework 7 core, ekstra bağımlılık yok) |
| Dosya adı doğrulanmıyor | `SafeFileNameRule` + `LocalAttachmentStore` çift savunma |
| Şifreler config dosyasında | Ortam değişkeni / Vault |
| Sadece SFTP'ye yazıyor | Ayrıca **Kafka event** yayınlıyor (`dbs.mail.received.v1`) |
| Operasyon RDP ile müdahale ediyor | REST ile manuel tetikleme + `/actuator/health` |

---

## 3. Yayınlanan olay

Ek içeren bir mail düştüğünde `dbs.mail.received.v1` topic'ine basılır
(partition key = `messageId`):

```json
{
  "eventId": "6f1c...",
  "eventType": "dbs.mail.received.v1",
  "aggregateId": "<CAFE123@banka.com.tr>",
  "occurredAt": "2026-08-03T08:23:18Z",
  "correlationId": "a91f...",
  "producer": "dbs-mail-reader",
  "headers": { "schemaVersion": "1" },
  "payload": {
    "messageId": "<CAFE123@banka.com.tr>",
    "mailbox": "dbs@banka.com.tr",
    "fromAddress": "firma@musteri.com.tr",
    "subject": "DBS dosyasi",
    "receivedAt": "2026-08-03T08:22:41Z",
    "attachments": [
      {
        "fileName": "DBS_20260803.txt",
        "contentType": "text/plain",
        "sizeBytes": 48213,
        "storedPath": "/DBS/DBS_20260803.txt",
        "sha256": "9f86d0..."
      }
    ]
  }
}
```

Ek **içeriği** olaya konmuyor — payload şişmesin ve KVKK açısından veri
gereksiz yere broker'da durmasın diye sadece referans taşınıyor.

`dbs.messaging.brokers: [kafka, rabbit]` yazıldığında aynı olay iki broker'a birden gider.

---

## 4. Veritabanı

Tek uygulama, iki veri kaynağı:

- **Oracle 19c** (`@Primary`) — JPA. `DBS_PROCESSED_MAIL`, `DBS_OUTBOX_EVENT`.
- **MS SQL Server** — salt okunur `JdbcTemplate`. Legacy `NAKITYONETIMI`
  veritabanındaki parametre tablosu (`GF.Parameter.GetParameterByParameterName`
  karşılığı, cache'li).

`OracleDataSourceConfig` / `MssqlDataSourceConfig` açık bean tanımı kullanıyor;
auto-configuration tek `spring.datasource` varsayar, iki DB'de yetmez.

DDL: `src/main/resources/db/oracle/V1__dbs_mail_reader_init.sql`.
`ddl-auto: validate` (PROD/ALFA) → şema ile entity uyumu açılışta doğrulanır.

> Flyway istenirse `spring-boot-starter-flyway` + `flyway-database-oracle`
> eklenip Oracle DataSource'a bağlanmalı. Bankacılık ortamlarında DDL genelde
> DBA tarafından uygulandığı için varsayılan olarak kapalı bıraktım.

---

## 5. Profiller

| Profil | Amaç | Öne çıkanlar |
|--------|------|--------------|
| `dev` | Geliştirici makinesi | `expose-detail: true`, `ddl-auto: update`, SFTP kapalı, bildirim maili kapalı, `trust-all-certificates`, Kafka+Rabbit ikisi de açık |
| `alfa` | Test/entegrasyon | Gerçek entegrasyonlar, SASL_SSL Kafka, `ddl-auto: validate`, DEBUG log |
| `prod` | Canlı | Sır yok (hepsi env), `expose-detail: false`, actuator kısıtlı, Outbox açık, SFTP anahtar tabanlı + known_hosts zorunlu |

```bash
java -jar dbs-mail-reader.jar --spring.profiles.active=alfa
```

---

## 6. Çalıştırma

```bash
# Altyapıyı ayağa kaldır (Kafka, Rabbit, Oracle, MSSQL, GreenMail)
docker compose up -d

# Derle
mvn clean install

# Çalıştır
cd dbs-mail-reader
mvn spring-boot:run -Dspring-boot.run.profiles=dev
```

Manuel tarama:

```bash
curl -X POST http://localhost:8080/api/v1/mail-reader/poll \
  -H 'Content-Type: application/json' \
  -H 'X-Correlation-Id: test-001' \
  -d '{"channel":"MANUAL","requestedBy":"bogac"}'
```

---

## 7. Spring Boot 4 notları

3.x'ten gelenler için değişenler (bu projede zaten uygulandı):

- `spring-boot-starter-web` → **`spring-boot-starter-webmvc`**
- `spring-boot-starter-aop` → **`spring-boot-starter-aspectj`**
- Jackson 2 → **Jackson 3**: `com.fasterxml.jackson` → `tools.jackson`.
  `ObjectMapper` yerine `JsonMapper` bean'i auto-configure ediliyor.
  Jackson 3'te exception'lar **unchecked** — `try/catch (JsonProcessingException)` gerekmiyor.
- `spring-retry` bağımlılık yönetimi kaldırıldı → **Spring Framework 7 core**
  `@Retryable` / `@ConcurrencyLimit` + `@EnableResilientMethods`
- Kafka için artık resmi starter var: **`spring-boot-starter-kafka`**
- Undertow desteği kaldırıldı; Servlet 6.1 baseline
- Actuator liveness/readiness probe'ları varsayılan olarak açık

---

## 8. Sıradaki adımlar

- [ ] **Sır yönetimi** — HashiCorp Vault veya Kubernetes Secret entegrasyonu
- [ ] **Dağıtık kilit** — ShedLock ya da Oracle advisory lock (çoklu pod için)
- [ ] **Consumer tarafı** — `dbs.mail.received.v1` dinleyip dosyayı işleyen modül
      (legacy `General.TextFileConverter` karşılığı)
- [ ] **Microsoft Graph adapter** — Exchange Online'a geçiş için. EWS Microsoft
      tarafından emekliye ayrılıyor; on-prem'de IMAP, bulutta Graph doğru yol.
- [ ] **Spring Security** — REST uçları şu an açık; OAuth2 resource server eklenecek
- [ ] **Testler** — Testcontainers (Kafka, Oracle) + GreenMail ile entegrasyon testleri
- [ ] **Kalan legacy modüller** — `DBS.SendInformationMail`, `DBS.EndOfDaySummaryMail`,
      `DBS.SendRetailerInformationMail`, `CEK.SendChequeResults`
