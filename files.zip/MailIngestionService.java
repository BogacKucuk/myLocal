package com.dbs.mailreader.application;

import com.dbs.common.aop.Auditable;
import com.dbs.common.aop.LogExecution;
import com.dbs.mailreader.application.rule.AttachmentRule;
import com.dbs.mailreader.application.rule.AttachmentRuleChain;
import com.dbs.mailreader.config.MailReaderProperties;
import com.dbs.mailreader.domain.event.MailReceivedEvent;
import com.dbs.mailreader.domain.model.MailAttachment;
import com.dbs.mailreader.domain.model.MailMessage;
import com.dbs.mailreader.domain.model.ProcessingOutcome;
import com.dbs.mailreader.domain.port.AttachmentStorePort;
import com.dbs.mailreader.domain.port.FileTransferPort;
import com.dbs.mailreader.domain.port.MailClientPort;
import com.dbs.mailreader.infrastructure.mail.MailClientResolver;
import com.dbs.mailreader.infrastructure.persistence.entity.ProcessedMail;
import com.dbs.mailreader.infrastructure.persistence.repository.ProcessedMailRepository;
import com.dbs.messaging.config.MessagingProperties;
import com.dbs.messaging.publisher.EventPublisher;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.stereotype.Service;

import java.nio.file.Path;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

/**
 * Mail alma akisinin orkestratoru.
 *
 * <p>Akis: <b>oku &rarr; idempotency kontrol &rarr; kurallardan gecir &rarr; diske yaz
 * &rarr; SFTP'ye gonder &rarr; event yayinla &rarr; maili arsivle</b>.</p>
 *
 * <p>Legacy koda gore en kritik degisiklik siralamada: eski kod maili
 * <i>hemen</i> siliyor, dosyayi <i>sonra</i> isliyordu. Aradaki herhangi bir
 * hata veriyi kalici olarak kaybettiriyordu. Burada mail ancak islem
 * tamamlandiktan sonra arsive tasiniyor.</p>
 */
@Slf4j
@Service
@RequiredArgsConstructor
@LogExecution(slowThresholdMs = 5000)
public class MailIngestionService {

    private final MailClientResolver mailClientResolver;
    private final AttachmentRuleChain ruleChain;
    private final AttachmentStorePort attachmentStore;
    private final ObjectProvider<FileTransferPort> fileTransfer;
    private final ProcessedMailRepository processedMailRepository;
    private final ProcessedMailRecorder recorder;
    private final EventPublisher eventPublisher;
    private final MailReaderProperties mailProperties;
    private final MessagingProperties messagingProperties;
    private final RejectionNotifier rejectionNotifier;

    /** Yapilandirmadaki varsayilanlarla bir tarama turu calistirir. */
    public List<ProcessingOutcome> pollOnce() {
        return pollOnce(mailProperties.getLookbackWindow(), mailProperties.getMaxMessagesPerPoll());
    }

    /**
     * Bir tarama turu calistirir.
     *
     * @param lookback    ne kadar geriye bakilacagi
     * @param maxMessages bu turda islenecek maksimum mail sayisi
     * @return her mail icin islem sonucu
     */
    @Auditable(action = "MAIL_POLL", entity = "MailMessage")
    public List<ProcessingOutcome> pollOnce(Duration lookback, int maxMessages) {
        Instant since = Instant.now().minus(lookback);
        MailClientPort client = mailClientResolver.resolve();

        List<MailMessage> messages = client.fetchMessages(since, maxMessages);
        List<ProcessingOutcome> outcomes = new ArrayList<>(messages.size());

        for (MailMessage message : messages) {
            try {
                outcomes.add(process(client, message));
            } catch (Exception ex) {
                // Tek bir mailin hatasi tum turu durdurmaz.
                // (Legacy kodda foreach icinde 'return' vardi; ilk sorunlu dosyadan
                //  sonraki tum dosyalar sessizce islenmeden kaliyordu.)
                log.error("Mail islenemedi: messageId={}", message.messageId(), ex);
                recorder.record(message, ProcessedMail.Outcome.FAILED, List.of(),
                        "DBS-MAIL-0002", ex.getMessage());
                outcomes.add(new ProcessingOutcome.Failed(
                        message.messageId(), "DBS-MAIL-0002", ex.getMessage()));
            }
        }
        log.info("Tarama turu bitti: {} mail islendi", outcomes.size());
        return outcomes;
    }

    // ------------------------------------------------------------------

    private ProcessingOutcome process(MailClientPort client, MailMessage message) {
        if (processedMailRepository.existsByMessageId(message.messageId())) {
            log.debug("Mail zaten islenmis, atlaniyor: {}", message.messageId());
            client.archive(message);
            return new ProcessingOutcome.Skipped(message.messageId(), "Daha once islendi");
        }

        if (!message.hasAttachments()) {
            recorder.record(message, ProcessedMail.Outcome.SKIPPED, List.of(), null, "Ek yok");
            client.archive(message);
            return new ProcessingOutcome.Skipped(message.messageId(), "Mailde ek bulunmuyor");
        }

        List<String> uploadedFiles = new ArrayList<>();
        List<MailReceivedEvent.AttachmentInfo> attachmentInfos = new ArrayList<>();

        for (MailAttachment attachment : message.attachments()) {
            AttachmentRule.Verdict verdict = ruleChain.evaluate(message, attachment);

            // Sealed interface + pattern matching: her durum tip guvenli ele aliniyor,
            // yeni bir Verdict tipi eklenirse derleyici burayi hata verir.
            switch (verdict) {
                case AttachmentRule.Verdict.Skip skip ->
                        log.info("Ek atlandi: dosya={} sebep={}", attachment.fileName(), skip.reason());

                case AttachmentRule.Verdict.Reject reject -> {
                    log.warn("Ek reddedildi: dosya={} kod={} sebep={}",
                            attachment.fileName(), reject.errorCode().code(), reject.reason());
                    rejectionNotifier.notifySender(message, attachment, reject);
                    recorder.record(message, ProcessedMail.Outcome.REJECTED,
                            List.of(attachment.fileName()), reject.errorCode().code(), reject.reason());
                    client.quarantine(message);
                    return new ProcessingOutcome.Rejected(message.messageId(), attachment.fileName(),
                            reject.errorCode().code(), reject.reason());
                }

                case AttachmentRule.Verdict.Accept unused -> {
                    Path stored = attachmentStore.store(message.messageId(), attachment);
                    String checksum = attachmentStore.sha256(attachment);

                    FileTransferPort transfer = fileTransfer.getIfAvailable();
                    String remotePath = transfer != null
                            ? transfer.upload(stored, attachment.fileName())
                            : stored.toString();

                    attachmentStore.archive(stored);
                    uploadedFiles.add(remotePath);
                    attachmentInfos.add(new MailReceivedEvent.AttachmentInfo(
                            attachment.fileName(), attachment.contentType(),
                            attachment.sizeBytes(), remotePath, checksum));
                }
            }
        }

        if (!attachmentInfos.isEmpty()) {
            publishMailReceived(message, attachmentInfos);
        }

        recorder.record(message, ProcessedMail.Outcome.PROCESSED, uploadedFiles, null, null);
        client.archive(message);
        return new ProcessingOutcome.Processed(message.messageId(), uploadedFiles);
    }

    private void publishMailReceived(MailMessage message,
                                     List<MailReceivedEvent.AttachmentInfo> attachments) {
        var event = MailReceivedEvent.of(
                message.messageId(),
                mailProperties.getImap().getMailbox(),
                message.fromAddress(),
                message.subject(),
                message.receivedAt(),
                attachments);

        String topic = messagingProperties.getKafka().getTopicPrefix()
                + messagingProperties.getKafka().getMailReceivedTopic();

        eventPublisher.publish(topic, event);
        log.info("MailReceivedEvent yayinlandi: topic={} messageId={} ekSayisi={}",
                topic, message.messageId(), attachments.size());
    }
}
